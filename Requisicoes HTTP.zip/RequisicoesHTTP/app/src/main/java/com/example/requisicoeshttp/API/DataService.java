package com.example.requisicoeshttp.API;

import com.example.requisicoeshttp.Model.DadosAtividades;
import com.example.requisicoeshttp.Model.Foto;
import com.example.requisicoeshttp.Model.Posts;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface DataService {

    @GET("/photos")
    Call<List<Foto>>recuperarFotos();

    @GET("/posts")
    Call<List<Posts>>recuperarPosts();

    @GET("dadosAtividades.php")
    Call<List<DadosAtividades>>recuperarDadosAtividades();

}
